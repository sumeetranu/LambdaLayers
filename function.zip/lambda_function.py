import json
from pyarrow.parquet import ParquetDataset 

def lambda_handler(event, context):
    
    dataset1 = ParquetDataset("userdata1.parquet") 
    dataset2= ParquetDataset("userdata1.parquet") 
    dataset3= ParquetDataset("wrongdata.parquet") 

    boolean_result_1v2 = dataset1.schema.equals(dataset2.schema)
    print("1 vs 2: " + str(boolean_result_1v2))
    boolean_result_1v3 = dataset1.schema.equals(dataset3.schema)
    print("1 vs 3: " + str(boolean_result_1v3))
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }